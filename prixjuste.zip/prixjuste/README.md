# Prixjuste

Comparateur de prix : on cherche un objet, on répond à quelques questions pour affiner, puis on suit le prix chez des marchands vérifiés (Amazon.fr, Fnac, Darty, Boulanger, Cdiscount, eBay.fr, Back Market).

## Fonctionnement actuel

- Page unique (`index.html`), sans dépendance ni build.
- Chaque bouton ouvre la recherche affinée chez le marchand.
- Les prix sont saisis par l'utilisateur après consultation du marchand. Ils sont conservés dans le `localStorage` du navigateur et alimentent la courbe d'évolution.
- Aucun prix n'est inventé.

## Lancer en local

Ouvrir `index.html` dans un navigateur.

## Publier avec GitHub Pages

1. Pousser le dépôt sur GitHub.
2. Settings → Pages → Source : `Deploy from a branch`, branche `main`, dossier `/ (root)`.
3. Le site sera disponible sur `https://<utilisateur>.github.io/<depot>/`.

## Pistes d'évolution

- Backend (Node ou Python) pour récupérer les prix automatiquement : API eBay Browse, flux d'affiliation (Awin, Effinity), API Google Shopping tierces.
- Rapprochement des produits par EAN/GTIN.
- Base de données pour l'historique des prix (aujourd'hui limité au navigateur).
- Vérification automatique des marchands : âge du domaine, Google Safe Browsing, avis clients.
